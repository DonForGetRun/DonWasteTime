package com.ppmoney.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 */
@SpringBootApplication
public class CalculateStart {
    public static void main(String[] args) {
        SpringApplication.run(CalculateStart.class, args);
    }
}
