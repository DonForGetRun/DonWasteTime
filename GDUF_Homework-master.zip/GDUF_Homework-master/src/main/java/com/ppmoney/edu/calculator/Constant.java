package com.ppmoney.edu.calculator;

/**
 *  常量
 */
public class Constant {
    public static final int ANNUALRATE = 0;
    public static final int DAILYRATE = 1;
    public static final int MONTHLY = 0;
    public static final int DAILY = 1;
}
